import React, { useState, useEffect } from 'react';
import './Testimonials.css';

const Testimonial = () => {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const testimonials = [
    {
      id: 1,
      name: "Dr. Sarah Johnson",
      position: "Chief Medical Officer",
      company: "Global Health Institute",
      image: "/api/placeholder/80/80",
      content: "Effective Solutions' JENDO technology has revolutionized our cardiovascular screening program. The non-invasive approach and AI-powered analysis have significantly improved our early detection rates.",
      rating: 5
    },
    {
      id: 2,
      name: "Hiroshi Tanaka",
      position: "Director of Innovation",
      company: "METI Japan",
      image: "/api/placeholder/80/80",
      content: "The collaboration with Effective Solutions on the OPHTHA project has been exceptional. Their technical expertise and commitment to international standards made them the ideal partner for our healthcare initiative.",
      rating: 5
    },
    {
      id: 3,
      name: "Colonel Michael Roberts",
      position: "Training Coordinator",
      company: "Sri Lanka Army",
      image: "/api/placeholder/80/80",
      content: "The Military Geographic Information System developed by Effective Solutions has transformed our training programs. The system's adherence to British military standards and user-friendly interface exceeded our expectations.",
      rating: 5
    },
    {
      id: 4,
      name: "Dr. Priya Patel",
      position: "WHO Representative",
      company: "World Health Organization",
      image: "/api/placeholder/80/80",
      content: "Effective Solutions was the first private organization we partnered with in Sri Lanka, and they've consistently delivered outstanding results. Their accident data management system has been instrumental in our road safety initiatives.",
      rating: 5
    },
    {
      id: 5,
      name: "Rajesh Kumar",
      position: "CTO",
      company: "SLT Mobitel",
      image: "/api/placeholder/80/80",
      content: "The ANTOMS platform has streamlined our fiber-to-home operations significantly. With over 2TB of data processed seamlessly, Effective Solutions has proven their capability in handling large-scale telecommunications infrastructure.",
      rating: 5
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [testimonials.length]);

  const handleDotClick = (index) => {
    setCurrentTestimonial(index);
  };

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, index) => (
      <span
        key={index}
        className={`star ${index < rating ? 'filled' : ''}`}
      >
        ★
      </span>
    ));
  };

  return (
    <section className="client-testimonials-section">
      <div className="container">
        <div className="section-header">
          <h2>What Our Clients Say</h2>
          <p>Trusted by leading organizations worldwide for innovative technology solutions</p>
        </div>

        <div className="testimonials-container">
          <div className="testimonial-card">
            <div className="testimonial-content">
              <div className="quote-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z" strokeWidth="2"/>
                  <path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z" strokeWidth="2"/>
                </svg>
              </div>
              
              <div className="testimonial-text">
                <p>"{testimonials[currentTestimonial].content}"</p>
              </div>

              <div className="testimonial-rating">
                {renderStars(testimonials[currentTestimonial].rating)}
              </div>

              <div className="testimonial-author">
                <div className="author-image">
                  <div className="avatar-placeholder">
                    {testimonials[currentTestimonial].name.split(' ').map(n => n[0]).join('')}
                  </div>
                </div>
                <div className="author-info">
                  <h4>{testimonials[currentTestimonial].name}</h4>
                  <p>{testimonials[currentTestimonial].position}</p>
                  <span>{testimonials[currentTestimonial].company}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="testimonial-navigation">
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={`nav-dot ${index === currentTestimonial ? 'active' : ''}`}
                onClick={() => handleDotClick(index)}
                aria-label={`Go to testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>

        <div className="client-logos">
          <div className="logos-grid">
            <div className="logo-item">
              <div className="logo-placeholder">WHO</div>
            </div>
            <div className="logo-item">
              <div className="logo-placeholder">METI</div>
            </div>
            <div className="logo-item">
              <div className="logo-placeholder">Army</div>
            </div>
            <div className="logo-item">
              <div className="logo-placeholder">Nestlé</div>
            </div>
            <div className="logo-item">
              <div className="logo-placeholder">Mobitel</div>
            </div>
            <div className="logo-item">
              <div className="logo-placeholder">Ohira</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonial;