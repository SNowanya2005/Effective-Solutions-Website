import React, { useState } from 'react';
import './Blogs.css';

const Blog = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPost, setSelectedPost] = useState(null);

  const categories = [
    { id: 'all', name: 'All Posts', count: 24 },
    { id: 'ai-ml', name: 'AI & Machine Learning', count: 8 },
    { id: 'biomedical', name: 'Biomedical Tech', count: 5 },
    { id: 'iot', name: 'IoT & Smart Systems', count: 6 },
    { id: 'industry-40', name: 'Industry 4.0', count: 5 }
  ];

  const blogPosts = [
    {
      id: 1,
      title: 'The Future of AI in Healthcare: Transforming Patient Care',
      category: 'ai-ml',
      excerpt: 'Explore how artificial intelligence is revolutionizing healthcare through predictive analytics, personalized medicine, and improved diagnostic accuracy.',
      content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit...',
      author: 'Dr. Mangala Karunaratne',
      authorRole: 'CEO & AI Research Lead',
      authorImage: '/images/authors/mangala.jpg',
      publishDate: '2024-01-15',
      readTime: '8 min read',
      image: '/images/blog/ai-healthcare.jpg',
      tags: ['AI', 'Healthcare', 'Machine Learning', 'Innovation'],
      featured: true,
      views: 2400,
      likes: 156
    },
    {
      id: 2,
      title: 'JENDO: Pioneering Non-Invasive Vascular Health Monitoring',
      category: 'biomedical',
      excerpt: 'Learn about our breakthrough technology that enables early detection of vascular diseases through advanced signal processing and AI algorithms.',
      content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit...',
      author: 'Dhanushka Jayathilake',
      authorRole: 'CTO & Biomedical Engineer',
      authorImage: '/images/authors/dhanushka.jpg',
      publishDate: '2024-01-12',
      readTime: '6 min read',
      image: '/images/blog/jendo-tech.jpg',
      tags: ['Biomedical', 'Healthcare', 'Innovation', 'Technology'],
      featured: true,
      views: 1800,
      likes: 142
    },
    {
      id: 3,
      title: 'IoT and Industry 4.0: Building Smart Manufacturing Systems',
      category: 'iot',
      excerpt: 'Discover how IoT technologies are transforming manufacturing through predictive maintenance, real-time monitoring, and automated quality control.',
      content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit...',
      author: 'Chinthika Karunaratne',
      authorRole: 'Director of Operations',
      authorImage: '/images/authors/chinthika.jpg',
      publishDate: '2024-01-10',
      readTime: '7 min read',
      image: '/images/blog/iot-manufacturing.jpg',
      tags: ['IoT', 'Industry 4.0', 'Manufacturing', 'Automation'],
      featured: false,
      views: 1600,
      likes: 98
    },
    {
      id: 4,
      title: 'OPHTHA: Revolutionizing Eye Care with AI-Powered Screening',
      category: 'biomedical',
      excerpt: 'How our AI-driven eye screening technology is making early detection of diabetic retinopathy more accessible and accurate worldwide.',
      content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit...',
      author: 'Dr. Samith Fernando',
      authorRole: 'Lead AI Engineer',
      authorImage: '/images/authors/samith.jpg',
      publishDate: '2024-01-08',
      readTime: '5 min read',
      image: '/images/blog/ophtha-ai.jpg',
      tags: ['AI', 'Healthcare', 'Computer Vision', 'Medical'],
      featured: false,
      views: 2100,
      likes: 167
    },
    {
      id: 5,
      title: 'The Rise of Brain-Computer Interfaces: MYNDRONE Technology',
      category: 'ai-ml',
      excerpt: 'Exploring the potential of mind-controlled technology and its applications in healthcare, meditation, and human-computer interaction.',
      content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit...',
      author: 'Ishara Walpola',
      authorRole: 'Research Scientist',
      authorImage: '/images/authors/ishara.jpg',
      publishDate: '2024-01-05',
      readTime: '9 min read',
      image: '/images/blog/myndrone-tech.jpg',
      tags: ['BCI', 'Neurotechnology', 'Innovation', 'Research'],
      featured: false,
      views: 1900,
      likes: 134
    },
    {
      id: 6,
      title: 'Smart Agriculture: IoT Solutions for Sustainable Farming',
      category: 'iot',
      excerpt: 'How IoT sensors and AI analytics are helping farmers optimize crop yields while reducing environmental impact and resource consumption.',
      content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit...',
      author: 'Priya Dissanayake',
      authorRole: 'IoT Solutions Architect',
      authorImage: '/images/authors/priya.jpg',
      publishDate: '2024-01-03',
      readTime: '6 min read',
      image: '/images/blog/smart-agriculture.jpg',
      tags: ['IoT', 'Agriculture', 'Sustainability', 'Technology'],
      featured: false,
      views: 1400,
      likes: 89
    },
    {
      id: 7,
      title: 'Digital Transformation in Sri Lankan Industries',
      category: 'industry-40',
      excerpt: 'Analyzing the current state of digital transformation in Sri Lanka and opportunities for businesses to embrace Industry 4.0 technologies.',
      content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit...',
      author: 'Mangala Karunaratne',
      authorRole: 'CEO & Technology Strategist',
      authorImage: '/images/authors/mangala.jpg',
      publishDate: '2024-01-01',
      readTime: '10 min read',
      image: '/images/blog/digital-transformation.jpg',
      tags: ['Industry 4.0', 'Digital Transformation', 'Sri Lanka', 'Business'],
      featured: false,
      views: 1700,
      likes: 112
    },
    {
      id: 8,
      title: 'Machine Learning in Predictive Maintenance',
      category: 'ai-ml',
      excerpt: 'Learn how machine learning algorithms are preventing equipment failures and reducing downtime in industrial applications.',
      content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit...',
      author: 'Dhanushka Jayathilake',
      authorRole: 'CTO & ML Engineer',
      authorImage: '/images/authors/dhanushka.jpg',
      publishDate: '2023-12-28',
      readTime: '7 min read',
      image: '/images/blog/predictive-maintenance.jpg',
      tags: ['Machine Learning', 'Predictive Maintenance', 'Industry', 'AI'],
      featured: false,
      views: 1500,
      likes: 95
    }
  ];

  const featuredPosts = blogPosts.filter(post => post.featured);
  const filteredPosts = blogPosts.filter(post => {
    const matchesCategory = activeCategory === 'all' || post.category === activeCategory;
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <div className="blog-page">
      {/* Hero Section - Using home page hero styles */}
      <section className="hero-container">
        {/* Animated Background Elements */}
        <div className="background-elements">
          <div className="grid-pattern"></div>
          <div className="bg-element bg-element-1"></div>
          <div className="bg-element bg-element-2"></div>
          <div className="bg-element bg-element-3"></div>
        </div>

        <div className="hero-content">
          <div className="content-wrapper">
            {/* Left Content */}
            <div className="content-left">
              {/* <h1 className="hero-title">
                Insights & Innovation in
                <span className="title-gradient"> Technology</span>
              </h1>*/}

               <h2 className="hero-title">
               Insights & Innovation in<br />
              <span className="title-gradient">Technology</span>
              </h2>
              <p className="hero-description">
                Explore cutting-edge insights, industry trends, and breakthrough innovations 
                in AI, IoT, biomedical technology, and Industry 4.0 from our expert team.
              </p>
              <div className="cta-buttons">
                <button className="btn-primary">
                  <span>Latest Articles</span>
                  <svg className="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path d="M5 12h14M12 5l7 7-7 7" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </button>
                <button className="btn-secondary">
                  <span>Subscribe</span>
                  <svg className="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" strokeWidth="2"/>
                    <polyline points="22,6 12,13 2,6" strokeWidth="2"/>
                  </svg>
                </button>
              </div>
            </div>

            {/* Right Content - Blog Stats */}
            <div className="content-right">
              <div className="blog-stats">
                <div className="stat-card">
                  <div className="stat-number">50+</div>
                  <div className="stat-label">Articles Published</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number">15K+</div>
                  <div className="stat-label">Monthly Readers</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number">500+</div>
                  <div className="stat-label">Newsletter Subscribers</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number">25+</div>
                  <div className="stat-label">Expert Authors</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="scroll-indicator">
          <div className="scroll-mouse">
            <div className="scroll-wheel"></div>
          </div>
        </div>
      </section>

      {/* Featured Posts Section */}
      <section className="featured-posts-section">
        <div className="container">
          <div className="section-header">
            <h2>Featured Articles</h2>
            <p>Our most popular and impactful content</p>
          </div>
          
          <div className="featured-posts-grid">
            {featuredPosts.map((post, index) => (
              <article 
                key={post.id}
                className={`featured-post ${index === 0 ? 'featured-post-large' : ''}`}
                onClick={() => setSelectedPost(post)}
              >
                <div className="post-image">
                  <img src={post.image} alt={post.title} />
                  <div className="post-overlay">
                    <span className="featured-badge">Featured</span>
                    <button className="read-more-btn">
                      <span>Read Article</span>
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <path d="M5 12h14M12 5l7 7-7 7" strokeWidth="2"/>
                      </svg>
                    </button>
                  </div>
                </div>
                <div className="post-content">
                  <div className="post-meta">
                    <span className="post-category">{categories.find(cat => cat.id === post.category)?.name}</span>
                    <span className="post-date">{formatDate(post.publishDate)}</span>
                  </div>
                  <h3 className="post-title">{post.title}</h3>
                  <p className="post-excerpt">{post.excerpt}</p>
                  <div className="post-footer">
                    <div className="author-info">
                      <img src={post.authorImage} alt={post.author} className="author-avatar" />
                      <div className="author-details">
                        <span className="author-name">{post.author}</span>
                        <span className="author-role">{post.authorRole}</span>
                      </div>
                    </div>
                    <div className="post-stats">
                      <span className="read-time">{post.readTime}</span>
                      <span className="post-views">{post.views} views</span>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Search and Filter Section */}
      <section className="filter-section">
        <div className="container">
          <div className="filter-content">
            <div className="search-bar">
              <div className="search-input-wrapper">
                <svg className="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <circle cx="11" cy="11" r="8" strokeWidth="2"/>
                  <path d="M21 21l-4.35-4.35" strokeWidth="2"/>
                </svg>
                <input
                  type="text"
                  placeholder="Search articles, topics, or technologies..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="search-input"
                />
              </div>
            </div>
            
            <div className="category-filters">
              {categories.map((category) => (
                <button
                  key={category.id}
                  className={`category-btn ${activeCategory === category.id ? 'active' : ''}`}
                  onClick={() => setActiveCategory(category.id)}
                >
                  {category.name}
                  <span className="category-count">{category.count}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Blog Posts Grid */}
      <section className="blog-posts-section">
        <div className="container">
          <div className="section-header">
            <h2>All Articles</h2>
            <p>Discover insights from our technology experts</p>
          </div>
          
          <div className="blog-posts-grid">
            {filteredPosts.map((post, index) => (
              <article 
                key={post.id}
                className="blog-post"
                style={{ animationDelay: `${index * 0.1}s` }}
                onClick={() => setSelectedPost(post)}
              >
                <div className="post-image">
                  <img src={post.image} alt={post.title} />
                  <div className="post-overlay">
                    <button className="read-more-btn">
                      <span>Read More</span>
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <path d="M5 12h14M12 5l7 7-7 7" strokeWidth="2"/>
                      </svg>
                    </button>
                  </div>
                </div>
                
                <div className="post-content">
                  <div className="post-meta">
                    <span className="post-category">{categories.find(cat => cat.id === post.category)?.name}</span>
                    <span className="post-date">{formatDate(post.publishDate)}</span>
                  </div>
                  
                  <h3 className="post-title">{post.title}</h3>
                  <p className="post-excerpt">{post.excerpt}</p>
                  
                  <div className="post-tags">
                    {post.tags.slice(0, 3).map((tag, index) => (
                      <span key={index} className="tag">{tag}</span>
                    ))}
                  </div>
                  
                  <div className="post-footer">
                    <div className="author-info">
                      <img src={post.authorImage} alt={post.author} className="author-avatar" />
                      <div className="author-details">
                        <span className="author-name">{post.author}</span>
                        <span className="read-time">{post.readTime}</span>
                      </div>
                    </div>
                    <div className="post-engagement">
                      <span className="post-likes">❤️ {post.likes}</span>
                      <span className="post-views">👁️ {post.views}</span>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="newsletter-section">
        <div className="container">
          <div className="newsletter-content">
            <div className="newsletter-text">
              <h2>Stay Updated with Latest Insights</h2>
              <p>Get the latest articles on AI, IoT, and Industry 4.0 delivered to your inbox</p>
            </div>
            <div className="newsletter-form">
              <input type="email" placeholder="Enter your email address" />
              <button className="subscribe-btn">
                <span>Subscribe</span>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path d="M5 12h14M12 5l7 7-7 7" strokeWidth="2"/>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Blog Post Modal */}
      {selectedPost && (
        <div className="post-modal-overlay" onClick={() => setSelectedPost(null)}>
          <div className="post-modal" onClick={(e) => e.stopPropagation()}>
            <button 
              className="modal-close"
              onClick={() => setSelectedPost(null)}
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path d="M18 6L6 18M6 6l12 12" strokeWidth="2"/>
              </svg>
            </button>
            
            <div className="modal-content">
              <div className="modal-header">
                <img src={selectedPost.image} alt={selectedPost.title} className="modal-image" />
                <div className="modal-meta">
                  <span className="modal-category">{categories.find(cat => cat.id === selectedPost.category)?.name}</span>
                  <span className="modal-date">{formatDate(selectedPost.publishDate)}</span>
                </div>
                <h1 className="modal-title">{selectedPost.title}</h1>
                <div className="modal-author">
                  <img src={selectedPost.authorImage} alt={selectedPost.author} className="modal-author-avatar" />
                  <div className="modal-author-info">
                    <span className="modal-author-name">{selectedPost.author}</span>
                    <span className="modal-author-role">{selectedPost.authorRole}</span>
                  </div>
                  <div className="modal-stats">
                    <span>{selectedPost.readTime}</span>
                    <span>•</span>
                    <span>{selectedPost.views} views</span>
                  </div>
                </div>
              </div>
              
              <div className="modal-body">
                <p className="modal-excerpt">{selectedPost.excerpt}</p>
                <div className="modal-text">
                  <p>This is where the full blog post content would appear. In a real implementation, you would fetch the full content from your CMS or API and render it here with proper formatting, images, and styling.</p>
                  <p>The content could include rich text, code snippets, embedded videos, and interactive elements depending on the topic and your blog's requirements.</p>
                </div>
                
                <div className="modal-tags">
                  <h4>Tags:</h4>
                  <div className="tags-list">
                    {selectedPost.tags.map((tag, index) => (
                      <span key={index} className="modal-tag">{tag}</span>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="modal-footer">
                <div className="modal-engagement">
                  <button className="engagement-btn">
                    <span>❤️ {selectedPost.likes}</span>
                  </button>
                  <button className="engagement-btn">
                    <span>💬 Comment</span>
                  </button>
                  <button className="engagement-btn">
                    <span>🔗 Share</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Blog;